package com.sjec.ems;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmpController {

    @Autowired
    private EmpService empService;

    @GetMapping("get/all")
    public List<Employee> getAllEmp() {
        return empService.getAllEmp();
    }

    @GetMapping("get/{id}")
    public Employee getEmpById(@PathVariable("id") Long empId) {
        return empService.getEmpById(empId);
    }

    @PostMapping("/add")
    public Employee addEmp(@RequestBody Employee employee) {
        return empService.addEmp(employee);
    }

    @DeleteMapping("/delete/{id}")
    public String delEmpById(@PathVariable("id") Long empId) {
        empService.delEmpById(empId);
        return "emp id " + empId + " deleted";
    }

    @PutMapping("update/{id}")
    public Employee updateEmp(@PathVariable("id") Long empId, @RequestBody Employee employee) {
        return empService.updateEmp(empId, employee);
    }


}

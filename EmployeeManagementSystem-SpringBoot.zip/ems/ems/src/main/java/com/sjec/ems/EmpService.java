package com.sjec.ems;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmpService {

    @Autowired
    private EmpRepo empRepo;

    public List<Employee> getAllEmp() {
        return empRepo.findAll();
    }

    public Employee getEmpById(Long empId) {
        return empRepo.findById(empId).get();
    }

    public Employee addEmp(Employee employee) {
        Optional<Employee> employeeOptional = empRepo.findByEmail(employee.getEmail());
        if(employeeOptional.isPresent()){
            throw new IllegalStateException("email taken already");
        }
        else{
            return empRepo.save(employee);
        }
    }

    public void delEmpById(Long empId) {
//        boolean exists = empRepo.existsById(empId);
//        if(!exists){
//            throw new IllegalStateException("emp with id " + empId + " does not exists");
//        }
        empRepo.deleteById(empId);
    }

    public Employee updateEmp(Long empId, Employee employee) {
        Employee empData = empRepo.findById(empId).get();

        empData.setEmpName(employee.getEmpName());
        empData.setEmail(employee.getEmail());
        empData.setJobTitle(employee.getJobTitle());
        empData.setDateOfJoin(employee.getDateOfJoin());

        return empRepo.save(empData);
    }
}
